"""Lokalna baza podataka."""
