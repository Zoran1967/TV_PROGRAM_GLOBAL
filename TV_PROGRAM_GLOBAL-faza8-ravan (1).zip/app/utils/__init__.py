"""Pomocne funkcije."""
