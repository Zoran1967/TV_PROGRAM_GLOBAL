"""Ekrani aplikacije."""
