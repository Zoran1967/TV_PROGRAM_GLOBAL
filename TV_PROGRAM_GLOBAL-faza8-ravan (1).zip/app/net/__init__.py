"""Mrezni sloj."""
