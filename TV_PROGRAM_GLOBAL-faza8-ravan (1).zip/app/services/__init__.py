"""Servisni sloj."""
