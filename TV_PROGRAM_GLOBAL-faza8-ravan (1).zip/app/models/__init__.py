"""Modeli podataka."""
